document.addEventListener('DOMContentLoaded', () => {
    const danhSachBanner = document.querySelectorAll('.banner_ct'); 
    const dauCham = document.querySelectorAll('.daucham .dc'); 
    const nutTiepTheo = document.querySelector('.next'); 
    const nutQuayLai = document.querySelector('.quaylai'); 
    const khungChua = document.querySelector('.bannerr'); 
    const tongSoSlide = danhSachBanner.length; 
    let slideHienTai = 0; 
    let tuDongChuyen;

    danhSachBanner.forEach((banner, chiSo) => {
        banner.style.left = `${chiSo * 100}%`;
    });

    function hienThiSlide(viTri) {
        slideHienTai = (viTri + tongSoSlide) % tongSoSlide; 
        const dichChuyen = -slideHienTai * 100; 
        khungChua.style.transform = `translateX(${dichChuyen}%)`;
        dauCham.forEach(cham => cham.classList.remove('active'));
        dauCham[slideHienTai].classList.add('active');
    }

    function chuyenSlideTiepTheo() {
        hienThiSlide(slideHienTai + 1);
    }

    function chuyenSlideQuayLai() {
        hienThiSlide(slideHienTai - 1);
    }

    function batDauTuDongChuyen() {
        tuDongChuyen = setInterval(chuyenSlideTiepTheo, 5000); // Chuyển slide mỗi 5 giây
    }

    function dungTuDongChuyen() {
        clearInterval(tuDongChuyen);
    }

    nutTiepTheo.addEventListener('click', () => {
        dungTuDongChuyen();
        chuyenSlideTiepTheo();
        batDauTuDongChuyen();
    });

    nutQuayLai.addEventListener('click', () => {
        dungTuDongChuyen();
        chuyenSlideQuayLai();
        batDauTuDongChuyen();
    });

    dauCham.forEach((cham, chiSo) => {
        cham.addEventListener('click', () => {
            dungTuDongChuyen();
            hienThiSlide(chiSo);
            batDauTuDongChuyen();
        });
    });

    hienThiSlide(slideHienTai);
    batDauTuDongChuyen();
});
